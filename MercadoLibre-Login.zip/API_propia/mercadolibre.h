#ifndef MERCADOLIBRE_H
#define MERCADOLIBRE_H

#include <QWidget>

namespace Ui {
class mercadoLibre;
}

class mercadoLibre : public QWidget
{
    Q_OBJECT

public:
    explicit mercadoLibre(QWidget *parent = nullptr);
    ~mercadoLibre();

private slots:
    void buscarProductoClicked();

private:
    Ui::mercadoLibre *ui;

    // Función para buscar un producto por nombre
    void buscarProductoPorNombre(const QString& nombreProducto);
};

#endif // MERCADOLIBRE_H
