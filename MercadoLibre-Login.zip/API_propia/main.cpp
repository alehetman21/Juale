
#include "login.h"
#include "mercadolibre.h"

#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Login w;
    w.show();

    // Crea una instancia de la ventana mercadoLibre
      mercadoLibre mercadolibreWindow;
      mercadolibreWindow.show();


    return a.exec();
}
