#include "mercadolibre.h"
#include "ui_mercadolibre.h"
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QEventLoop>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QTextStream>
#include <QDebug>
#include <QPixmap>




mercadoLibre::mercadoLibre(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::mercadoLibre)
{
    ui->setupUi(this);

    // Conectar el evento de clic del botón al slot buscarProductoClicked
    connect(ui->pushButtonBuscar, &QPushButton::clicked, this, &mercadoLibre::buscarProductoClicked);
}

mercadoLibre::~mercadoLibre()
{
    delete ui;
}

QString vectorProd[5];
double vectorPrecio[5];
QString vectorUrl[5];
void mercadoLibre::buscarProductoPorNombre(const QString& nombreProducto)
{
    QNetworkAccessManager manager;

    // URL de la API de búsqueda de Mercado Libre
    QString apiUrl = "https://api.mercadolibre.com/sites/MLA/search?q=%1";

    // Codifica el nombre del producto para incluirlo en la URL
    QString encodedProductName = QUrl::toPercentEncoding(nombreProducto);

    // Construye la URL de búsqueda con el nombre del producto
    QString searchUrl = apiUrl.arg(encodedProductName);

    // Agrega tu clave de la API de Mercado Libre en el encabezado
    QNetworkRequest request(searchUrl);
    request.setRawHeader("Authorization", "Bearer 5275668825390886");

    QNetworkReply *reply = manager.get(request);

    QEventLoop loop;
    QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    loop.exec();

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();

        // Analiza la respuesta JSON
        QJsonDocument jsonResponse = QJsonDocument::fromJson(response);
        QJsonObject jsonObject = jsonResponse.object();

        // Accede a los resultados de la búsqueda
        QJsonArray results = jsonObject.value("results").toArray();

        // Verifica si se encontraron resultados
        if (!results.isEmpty()) {
            for(int y=0; y<5; y++){
                // Tomar el primer resultado como ejemplo
                QJsonObject primerResultado = results.at(y).toObject();

                // Extraer los datos que necesites del primer resultado
                QString title = primerResultado.value("title").toString();
                double price = primerResultado.value("price").toDouble();
                QString imageUrl = primerResultado.value("thumbnail").toString();

                qDebug() << "Título del producto: " << title;
                qDebug() << "Precio del producto: " << price;
                qDebug() << "URL: " << imageUrl;

                vectorProd[y] = title;
                vectorPrecio[y] = price;
                vectorUrl[y] = imageUrl;


            }

        } else {
            qDebug() << "No se encontraron resultados para el producto: " << nombreProducto;
        }

    } else {
        qDebug() << "Error en la solicitud: " << reply->errorString();
    }



    reply->deleteLater();
}

void mercadoLibre::buscarProductoClicked()
{
    QString nombreProducto = ui->lineEditProducto->text();
    buscarProductoPorNombre(nombreProducto);

        ui->prod1->setText(vectorProd[0]);
        ui->prod2->setText(vectorProd[1]);
        ui->prod3->setText(vectorProd[2]);
        ui->prod4->setText(vectorProd[3]);
        ui->prod5->setText(vectorProd[4]);

        ui->precio1->setText(QString::number(vectorPrecio[0]));
        ui->precio2->setText(QString::number(vectorPrecio[1]));
        ui->precio3->setText(QString::number(vectorPrecio[2]));
        ui->precio4->setText(QString::number(vectorPrecio[3]));
        ui->precio5->setText(QString::number(vectorPrecio[4]));

        // Cargar las imágenes de los productos
        for (int i = 0; i < 5; ++i) {
            QNetworkAccessManager imageManager;
            QNetworkReply *imageReply = imageManager.get(QNetworkRequest(QUrl(vectorUrl[i])));
            QEventLoop imageLoop;
            QObject::connect(imageReply, &QNetworkReply::finished, &imageLoop, &QEventLoop::quit);
            imageLoop.exec();

            if (imageReply->error() == QNetworkReply::NoError) {
                QByteArray imageData = imageReply->readAll();
                QPixmap pixmap;
                pixmap.loadFromData(imageData);
                QLabel* imgLabel = findChild<QLabel*>(QString("img%1").arg(i + 1));
                if (imgLabel) {
                    imgLabel->setPixmap(pixmap);
                    imgLabel->setScaledContents(true);
                }
            } else {
                qDebug() << "Error al cargar la imagen del producto " << i << ": " << imageReply->errorString();
            }

            imageReply->deleteLater();
}



}
