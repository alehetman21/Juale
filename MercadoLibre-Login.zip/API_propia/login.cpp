#include "login.h"
#include "ui_login.h"

#include <QDebug>

Login::Login(QWidget *parent) : QWidget(parent),
                                ui(new Ui::Login),
                                manager( new QNetworkAccessManager( this ) )

{
    ui->setupUi(this);

    validar = new Ventana;

    connect( ui->pbIngresar, SIGNAL(pressed()), this, SLOT(slot_validar_con_API()));
    connect( ui->leClave, SIGNAL(returnPressed()), this, SLOT(slot_validar_con_API()));
    connect( manager, SIGNAL(finished(QNetworkReply*)),
             this, SLOT(slot_descargaFinalizada(QNetworkReply*)));

    ui->leUsuario->setFocus();

}

Login::~Login()
{
    delete ui;
    delete validar;
}

void Login::slot_validar_con_API()  {
    // Aqui armar la solicitud para el webservice

    QString sUrl = "https://krokos.com.ar/apiJuanaPOO.php?usuario=";
    sUrl += ui->leUsuario->text();
    sUrl += "&clave=";
    sUrl += ui->leClave->text() + "&i=2343";

    manager->get( QNetworkRequest( QUrl( sUrl ) ) );
}

/**
 * @brief Login::slot_descargaFinalizada se ejecuta cuando la respuesta llega aqui
 * @param reply es toda la info que mando el server
 */
void Login::slot_descargaFinalizada( QNetworkReply * reply )  {
    QByteArray ba = reply->readAll();

    validar->setMensaje( ba );
    validar->show();
    this->hide();
}






